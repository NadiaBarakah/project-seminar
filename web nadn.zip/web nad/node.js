const express = require('express');
const nodemailer = require('nodemailer');
const cors = require('cors');
const app = express();
const port = 3000;

app.use(cors());

const transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: 'your-email@gmail.com',
    pass: 'your-email-password',
  },
});

app.get('/send-email', async (req, res) => {
  try {
    const info = await transporter.sendMail({
      from: 'your-email@gmail.com',
      to: 'recipient-email@example.com',
      subject: 'Subject of the email',
      text: 'Body of the email',
    });

    console.log('Email sent:', info.response);
    res.json({ message: 'Email sent successfully' });
  } catch (error) {
    console.error('Error sending email:', error);
    res.status(500).json({ error: 'Failed to send email' });
  }
});

app.listen(port, () => {
    console.log(`Server berjalan di http://localhost:${port}`);
  });
