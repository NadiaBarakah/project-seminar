const questions = [
    {
        question: "Apa yang membedakan gerak jatuh bebas dengan gerak vertikal ke atas?",
        answers: [
            { text: "Arah gerak", correct: true },
            { text: "Kecepatan", correct: false },
            { text: "Waktu tempuh", correct: false },
            { text: "Massa benda", correct: false }
        ]
    },
    // ... (tambahkan soal lainnya)
];
