// server.js
// ... (kode yang sudah ada sebelumnya)

app.post('/send-email', async (req, res) => {
    const { emails, data } = req.body;
  
    // Konfigurasi transporter Nodemailer
    const transporter = nodemailer.createTransport({
      service: 'gmail',
      auth: {
        user: 'deritamahsiswa9@gmail.com',  // Ganti dengan email Anda
        pass: 'nadiakuy123'         // Ganti dengan password email Anda
      }
    });
  
    // Kirim email ke setiap alamat
    const sendEmails = async () => {
      const promises = emails.map(async (email) => {
        // Konfigurasi email
        const mailOptions = {
          from: '',
          to: email,
          subject: 'Hasil Percobaan',
          text: `Data Hasil Percobaan:\n\n${data}`
        };
  
        // Kirim email
        return transporter.sendMail(mailOptions);
      });
  
      return Promise.all(promises);
    };
  
    try {
        await transporter.sendMail(mailOptions);
        console.log('Email terkirim');
        res.status(200).json({ status: 'Email terkirim' });
      } catch (error) {
        console.error('Gagal mengirim email:', error);
        res.status(500).json({ error: 'Terjadi kesalahan dalam pengiriman email.' });
      }
    });
  
  // ... (kode yang sudah ada setelahnya)
  